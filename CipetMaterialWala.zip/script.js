
const DATA={"Communication English-II":[{"title":"Unit 1","file":"notes/english/unit1_communication_basics.pdf","size":"1.2 MB"}],"Engineering Mathematics":[{"title":"Formula Sheet","file":"notes/math/formula_sheet.pdf","size":"300 KB"}]};
const subjectGrid=document.getElementById('subjectGrid');
const unitsSection=document.getElementById('units');
const unitsTitle=document.getElementById('unitsTitle');
const unitList=document.getElementById('unitList');
const stats=document.getElementById('stats');
const search=document.getElementById('search');
const overlay=document.getElementById('overlay');
const pdfFrame=document.getElementById('pdfFrame');
const pdfTitle=document.getElementById('pdfTitle');
const downloadLink=document.getElementById('downloadLink');
const closeModal=document.getElementById('closeModal');
const backToSubjects=document.getElementById('backToSubjects');
stats.textContent=Object.values(DATA).reduce((a,b)=>a+b.length,0)+' notes';
for(const subject in DATA){const card=document.createElement('article');card.className='card subject';card.dataset.subject=subject;card.dataset.count=DATA[subject].length;card.innerHTML='<div class="chip">'+subject.split(' ')[0]+'</div><h3>'+subject+'</h3><p>'+DATA[subject][0].title+' ...</p>';subjectGrid.appendChild(card);}
subjectGrid.addEventListener('click',(e)=>{const card=e.target.closest('.subject');if(!card)return;openSubject(card.dataset.subject);});
function openSubject(name){unitsTitle.textContent=name;unitList.innerHTML='';DATA[name].forEach((u,i)=>{const row=document.createElement('div');row.className='unit';row.innerHTML='<div class="title"><span class="chip">Unit '+(i+1)+'</span><div><div><strong>'+u.title+'</strong></div><div class="muted" style="font-size:12px">'+u.size+'</div></div></div><div class="row-actions"><button class="btn" data-preview="'+u.file+'" data-title="'+u.title+'">👀 View</button><a class="btn" href="'+u.file+'" download>⬇ Download</a></div>';unitList.appendChild(row);});document.getElementById('subjects').classList.add('hide');unitsSection.classList.remove('hide');}
backToSubjects.addEventListener('click',()=>{unitsSection.classList.add('hide');document.getElementById('subjects').classList.remove('hide');});
document.body.addEventListener('click',(e)=>{const btn=e.target.closest('[data-preview]');if(!btn)return;pdfFrame.src=btn.getAttribute('data-preview');downloadLink.href=btn.getAttribute('data-preview');pdfTitle.textContent=btn.getAttribute('data-title');overlay.classList.add('show');});
closeModal.addEventListener('click',()=>{overlay.classList.remove('show');pdfFrame.src='';});
overlay.addEventListener('click',(e)=>{if(e.target===overlay){overlay.classList.remove('show');pdfFrame.src='';}});
search.addEventListener('input',(e)=>{const q=e.target.value.toLowerCase().trim();$$('#subjectGrid .subject').forEach(card=>{const name=card.dataset.subject.toLowerCase();const matchSubject=name.includes(q);const matchUnits=(DATA[card.dataset.subject]||[]).some(u=>u.title.toLowerCase().includes(q));card.classList.toggle('hide',!(matchSubject||matchUnits));});});
document.getElementById('yr').textContent=new Date().getFullYear();
const $$=(q,el=document)=>Array.from(el.querySelectorAll(q));
